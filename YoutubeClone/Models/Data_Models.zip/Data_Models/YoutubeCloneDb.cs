﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace YoutubeClone.Models.Data_Models {
    public class YoutubeCloneDb: DbContext {
        public YoutubeCloneDb() : base("cnx") {
            Database.SetInitializer(new  YoutubeCloneInitializer());
        }

        public DbSet<Video> Videos { get; set; }
        public DbSet<Utilisateur> Utilisateurs { get; set; }
        public DbSet<Chaine> Chaines { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder) {
            modelBuilder.Conventions.Remove<OneToManyCascadeDeleteConvention>();
        }
    }

    public class YoutubeCloneInitializer :
        DropCreateDatabaseIfModelChanges<YoutubeCloneDb> {
        public YoutubeCloneInitializer() : base() { }
        public override void InitializeDatabase(YoutubeCloneDb context) {
            base.InitializeDatabase(context);

        }
        protected override void Seed(YoutubeCloneDb context) {

            Utilisateur u1 = new Utilisateur() { Username = "kidbestcode", Courriel = "David.genois13@gmail.com", HashPassword = "patate" };
            Utilisateur u2 = new Utilisateur() { Username = "ace13", Courriel = "e1671873@cmaisonneuve.qc.ca", HashPassword = "patate" };
            Utilisateur u3 = new Utilisateur() { Username = "jijininja", Courriel = "frandre@videotron.ca", HashPassword = "patate" };
            Utilisateur u4 = new Utilisateur() { Username = "buzz5", Courriel = "a@a.com", HashPassword = "patate" };
            Utilisateur u5 = new Utilisateur() { Username = "marcamnesia", Courriel = "b@b.com", HashPassword = "patate" };
            Chaine ch1 = new Chaine() { Categorie_Chaine = Categorie.Fashion, Name = "Pewdiepie", Description = "Patate Patate", Utilisateur = u1 };
            Chaine ch2 = new Chaine() { Categorie_Chaine = Categorie.Fashion, Name = "ReactGaming", Description = "Patate Patate", Utilisateur = u2 };
            Chaine ch3 = new Chaine() { Categorie_Chaine = Categorie.Fashion, Name = "Jacksepticeye", Description = "Patate Patate", Utilisateur = u4 };
            Chaine ch4 = new Chaine() { Categorie_Chaine = Categorie.Fashion, Name = "SxyHxy", Description = "Patate Patate", Utilisateur = u5 };
            Chaine ch5 = new Chaine() { Categorie_Chaine = Categorie.Fashion, Name = "Molfried", Description = "Patate Patate", Utilisateur = u4 };
            Video v1 = new Video() { Name = "Potato Patata", Description = "This is a description", Categorie_Video = Categorie.React, DatePublished = DateTime.Today, Channel = ch3 };
            Video v2 = new Video() { Name = "Preztel Apocalypse", Description = "This is a description", Categorie_Video = Categorie.React, DatePublished = DateTime.Today, Channel = ch3 };
            Video v3 = new Video() { Name = "Pizza mania", Description = "This is a description", Categorie_Video = Categorie.React, DatePublished = DateTime.Today, Channel = ch1 };
            Video v4 = new Video() { Name = "Patata On a Pazza", Description = "This is a description", Categorie_Video = Categorie.React, DatePublished = DateTime.Today, Channel = ch5 };
            Video v5 = new Video() { Name = "Why are we not rocks", Description = "This is a description", Categorie_Video = Categorie.React, DatePublished = DateTime.Today, Channel = ch2 };


            context.Utilisateurs.Add(u1);
            context.Utilisateurs.Add(u2);
            context.Utilisateurs.Add(u3);
            context.Utilisateurs.Add(u4);
            context.Utilisateurs.Add(u5);
            context.Chaines.Add(ch1);
            context.Chaines.Add(ch2);
            context.Chaines.Add(ch3);
            context.Chaines.Add(ch4);
            context.Chaines.Add(ch5);
            context.Videos.Add(v1);
            context.Videos.Add(v2);
            context.Videos.Add(v3);
            context.Videos.Add(v4);
            context.Videos.Add(v5);
            context.SaveChanges();
        }
    }
}